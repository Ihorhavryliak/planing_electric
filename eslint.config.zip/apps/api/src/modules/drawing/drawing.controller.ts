import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Inject,
  Param,
  ParseUUIDPipe,
  Patch,
  Post,
  Put,
  UseGuards,
} from '@nestjs/common';
import {
  createPointSchema,
  createRouteSchema,
  setCalibrationSchema,
  updatePointSchema,
  updateRouteSchema,
  type CreatePointInput,
  type CreateRouteInput,
  type PlanCalculation,
  type PlanDrawing,
  type PublicCalibration,
  type PublicPoint,
  type PublicRoute,
  type PublicUser,
  type SetCalibrationInput,
  type UpdatePointInput,
  type UpdateRouteInput,
} from '@drawmyplace/contracts';
import { ZodValidationPipe } from '../../common/pipes/zod-validation.pipe';
import { AuthGuard } from '../auth/auth.guard';
import { CurrentUser } from '../auth/current-user.decorator';
import { DrawingService } from './drawing.service';

const uuid = () => new ParseUUIDPipe({ version: '4' });

@Controller()
@UseGuards(AuthGuard)
export class DrawingController {
  constructor(@Inject(DrawingService) private readonly drawing: DrawingService) {}

  @Get('plans/:planId/drawing')
  getDrawing(
    @CurrentUser() user: PublicUser,
    @Param('planId', uuid()) planId: string,
  ): Promise<PlanDrawing> {
    return this.drawing.getDrawing(user.id, planId);
  }

  @Get('plans/:planId/calculation')
  calculate(
    @CurrentUser() user: PublicUser,
    @Param('planId', uuid()) planId: string,
  ): Promise<PlanCalculation> {
    return this.drawing.calculate(user.id, planId);
  }

  // ------------------------------------------------------------ calibration

  @Put('plans/:planId/calibration')
  setCalibration(
    @CurrentUser() user: PublicUser,
    @Param('planId', uuid()) planId: string,
    @Body(new ZodValidationPipe(setCalibrationSchema))
    input: SetCalibrationInput,
  ): Promise<PublicCalibration> {
    return this.drawing.setCalibration(user.id, planId, input);
  }

  @Delete('plans/:planId/calibration')
  @HttpCode(HttpStatus.NO_CONTENT)
  deleteCalibration(
    @CurrentUser() user: PublicUser,
    @Param('planId', uuid()) planId: string,
  ): Promise<void> {
    return this.drawing.deleteCalibration(user.id, planId);
  }

  // ----------------------------------------------------------------- points

  @Post('plans/:planId/points')
  createPoint(
    @CurrentUser() user: PublicUser,
    @Param('planId', uuid()) planId: string,
    @Body(new ZodValidationPipe(createPointSchema)) input: CreatePointInput,
  ): Promise<PublicPoint> {
    return this.drawing.createPoint(user.id, planId, input);
  }

  @Patch('points/:pointId')
  updatePoint(
    @CurrentUser() user: PublicUser,
    @Param('pointId', uuid()) pointId: string,
    @Body(new ZodValidationPipe(updatePointSchema)) input: UpdatePointInput,
  ): Promise<PublicPoint> {
    return this.drawing.updatePoint(user.id, pointId, input);
  }

  @Delete('points/:pointId')
  @HttpCode(HttpStatus.NO_CONTENT)
  deletePoint(
    @CurrentUser() user: PublicUser,
    @Param('pointId', uuid()) pointId: string,
  ): Promise<void> {
    return this.drawing.deletePoint(user.id, pointId);
  }

  // ----------------------------------------------------------------- routes

  @Post('plans/:planId/routes')
  createRoute(
    @CurrentUser() user: PublicUser,
    @Param('planId', uuid()) planId: string,
    @Body(new ZodValidationPipe(createRouteSchema)) input: CreateRouteInput,
  ): Promise<PublicRoute> {
    return this.drawing.createRoute(user.id, planId, input);
  }

  @Patch('routes/:routeId')
  updateRoute(
    @CurrentUser() user: PublicUser,
    @Param('routeId', uuid()) routeId: string,
    @Body(new ZodValidationPipe(updateRouteSchema)) input: UpdateRouteInput,
  ): Promise<PublicRoute> {
    return this.drawing.updateRoute(user.id, routeId, input);
  }

  @Delete('routes/:routeId')
  @HttpCode(HttpStatus.NO_CONTENT)
  deleteRoute(
    @CurrentUser() user: PublicUser,
    @Param('routeId', uuid()) routeId: string,
  ): Promise<void> {
    return this.drawing.deleteRoute(user.id, routeId);
  }
}
