import {
  point2DSchema,
  pointPropertiesSchema,
  routeGeometrySchema,
  routeSettingsSchema,
  lengthUnitSchema,
  type PublicCalibration,
  type PublicPoint,
  type PublicRoute,
} from '@drawmyplace/contracts';
import type { CalibrationRow, PointRow, RouteRow } from './drawing.repository';

export function toPublicCalibration(row: CalibrationRow): PublicCalibration {
  return {
    planId: row.planId,
    pointA: point2DSchema.parse(row.pointA),
    pointB: point2DSchema.parse(row.pointB),
    realDistance: row.knownDistance,
    unit: lengthUnitSchema.parse(row.unit),
    metersPerUnit: row.metersPerPixel,
    updatedAt: row.updatedAt.toISOString(),
  };
}

export function toPublicPoint(row: PointRow): PublicPoint {
  return {
    id: row.id,
    floorId: row.floorId,
    type: row.type,
    x: row.x,
    y: row.y,
    rotation: row.rotation,
    label: row.label,
    mountingHeight: row.mountingHeight,
    properties: pointPropertiesSchema.parse(row.properties),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export function toPublicRoute(row: RouteRow): PublicRoute {
  return {
    id: row.id,
    floorId: row.floorId,
    circuitId: row.circuitId,
    geometry: routeGeometrySchema.parse(row.geometry),
    settings: routeSettingsSchema.parse(row.settings),
    updatedAt: row.updatedAt.toISOString(),
  };
}
