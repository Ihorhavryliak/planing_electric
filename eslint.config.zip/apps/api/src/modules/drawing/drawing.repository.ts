import { Inject, Injectable } from '@nestjs/common';
import { asc, count, eq } from 'drizzle-orm';
import {
  cableRoutes,
  calibrations,
  electricalPoints,
  type Database,
} from '@drawmyplace/database';
import type {
  CreatePointInput,
  CreateRouteInput,
  UpdatePointInput,
  UpdateRouteInput,
} from '@drawmyplace/contracts';
import { DatabaseService } from '../../database/database.service';

export type CalibrationRow = typeof calibrations.$inferSelect;
export type PointRow = typeof electricalPoints.$inferSelect;
export type RouteRow = typeof cableRoutes.$inferSelect;

export interface CalibrationValues {
  pointA: { x: number; y: number };
  pointB: { x: number; y: number };
  knownDistance: number;
  unit: string;
  metersPerPixel: number;
}

@Injectable()
export class DrawingRepository {
  private readonly db: Database;

  constructor(@Inject(DatabaseService) database: DatabaseService) {
    this.db = database.db;
  }

  // ------------------------------------------------------------ calibration

  async findCalibration(planId: string): Promise<CalibrationRow | null> {
    const [row] = await this.db
      .select()
      .from(calibrations)
      .where(eq(calibrations.planId, planId))
      .limit(1);

    return row ?? null;
  }

  /** One calibration per plan (unique index); recalibration replaces it. */
  async upsertCalibration(
    planId: string,
    values: CalibrationValues,
  ): Promise<CalibrationRow> {
    const [row] = await this.db
      .insert(calibrations)
      .values({ planId, ...values })
      .onConflictDoUpdate({
        target: calibrations.planId,
        set: { ...values, updatedAt: new Date() },
      })
      .returning();

    if (!row) {
      throw new Error('Failed to save calibration');
    }

    return row;
  }

  async deleteCalibration(planId: string): Promise<void> {
    await this.db.delete(calibrations).where(eq(calibrations.planId, planId));
  }

  // ----------------------------------------------------------------- points

  listPoints(floorId: string): Promise<PointRow[]> {
    return this.db
      .select()
      .from(electricalPoints)
      .where(eq(electricalPoints.floorId, floorId))
      .orderBy(asc(electricalPoints.createdAt), asc(electricalPoints.id));
  }

  async countPoints(floorId: string): Promise<number> {
    const [row] = await this.db
      .select({ value: count() })
      .from(electricalPoints)
      .where(eq(electricalPoints.floorId, floorId));

    return row?.value ?? 0;
  }

  async findPoint(pointId: string): Promise<PointRow | null> {
    const [row] = await this.db
      .select()
      .from(electricalPoints)
      .where(eq(electricalPoints.id, pointId))
      .limit(1);

    return row ?? null;
  }

  async createPoint(
    floorId: string,
    input: CreatePointInput,
  ): Promise<PointRow> {
    const [row] = await this.db
      .insert(electricalPoints)
      .values({
        floorId,
        type: input.type,
        x: input.x,
        y: input.y,
        rotation: input.rotation,
        label: input.label ?? null,
        mountingHeight: input.mountingHeight ?? null,
        properties: input.properties,
      })
      .returning();

    if (!row) {
      throw new Error('Failed to create point');
    }

    return row;
  }

  async updatePoint(
    pointId: string,
    input: UpdatePointInput,
  ): Promise<PointRow> {
    const [row] = await this.db
      .update(electricalPoints)
      .set({
        updatedAt: new Date(),
        ...(input.type !== undefined ? { type: input.type } : {}),
        ...(input.x !== undefined ? { x: input.x } : {}),
        ...(input.y !== undefined ? { y: input.y } : {}),
        ...(input.rotation !== undefined ? { rotation: input.rotation } : {}),
        ...(input.label !== undefined ? { label: input.label } : {}),
        ...(input.mountingHeight !== undefined
          ? { mountingHeight: input.mountingHeight }
          : {}),
        ...(input.properties !== undefined
          ? { properties: input.properties }
          : {}),
      })
      .where(eq(electricalPoints.id, pointId))
      .returning();

    if (!row) {
      throw new Error('Failed to update point');
    }

    return row;
  }

  async deletePoint(pointId: string): Promise<void> {
    await this.db
      .delete(electricalPoints)
      .where(eq(electricalPoints.id, pointId));
  }

  // ----------------------------------------------------------------- routes

  listRoutes(floorId: string): Promise<RouteRow[]> {
    return this.db
      .select()
      .from(cableRoutes)
      .where(eq(cableRoutes.floorId, floorId))
      .orderBy(asc(cableRoutes.createdAt), asc(cableRoutes.id));
  }

  async countRoutes(floorId: string): Promise<number> {
    const [row] = await this.db
      .select({ value: count() })
      .from(cableRoutes)
      .where(eq(cableRoutes.floorId, floorId));

    return row?.value ?? 0;
  }

  async findRoute(routeId: string): Promise<RouteRow | null> {
    const [row] = await this.db
      .select()
      .from(cableRoutes)
      .where(eq(cableRoutes.id, routeId))
      .limit(1);

    return row ?? null;
  }

  async createRoute(
    floorId: string,
    input: CreateRouteInput,
  ): Promise<RouteRow> {
    const [row] = await this.db
      .insert(cableRoutes)
      .values({
        floorId,
        geometry: input.geometry,
        circuitId: input.circuitId ?? null,
        settings: input.settings,
      })
      .returning();

    if (!row) {
      throw new Error('Failed to create route');
    }

    return row;
  }

  async updateRoute(
    routeId: string,
    input: UpdateRouteInput,
  ): Promise<RouteRow> {
    const [row] = await this.db
      .update(cableRoutes)
      .set({
        updatedAt: new Date(),
        ...(input.geometry !== undefined ? { geometry: input.geometry } : {}),
        ...(input.circuitId !== undefined
          ? { circuitId: input.circuitId }
          : {}),
        ...(input.settings !== undefined ? { settings: input.settings } : {}),
      })
      .where(eq(cableRoutes.id, routeId))
      .returning();

    if (!row) {
      throw new Error('Failed to update route');
    }

    return row;
  }

  async deleteRoute(routeId: string): Promise<void> {
    await this.db.delete(cableRoutes).where(eq(cableRoutes.id, routeId));
  }
}
