import { rm } from 'node:fs/promises';
import type {
  PlanCalculation,
  PlanDrawing,
  PublicCalibration,
  PublicFloor,
  PublicPlan,
  PublicPoint,
  PublicProject,
  PublicRoute,
  PublicUser,
} from '@drawmyplace/contracts';
import request from 'supertest';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { createTestApp, type TestApp } from './create-test-app';

const API = '/api/v1';
const PASSWORD = 'correct-horse-battery';
const MISSING = '7d03f7d0-8ca7-4f53-9851-c8d3f2bd5f86';

interface HeaderCarrier {
  headers: Record<string, string | string[] | undefined>;
}

function cookiePair(response: HeaderCarrier): string {
  const header = response.headers['set-cookie'];
  const values = Array.isArray(header)
    ? header
    : typeof header === 'string'
      ? [header]
      : [];
  const pair = values[0]?.split(';')[0];

  if (!pair) {
    throw new Error('Expected a session cookie');
  }

  return pair;
}

describe('Drawing API', () => {
  let testApp: TestApp;
  let emailCounter = 0;

  beforeAll(async () => {
    testApp = await createTestApp();
  });

  afterAll(async () => {
    await testApp.close();

    if (process.env.STORAGE_DIR) {
      await rm(process.env.STORAGE_DIR, { recursive: true, force: true });
    }
  });

  function server(): request.SuperTest<request.Test> {
    return request(testApp.app.getHttpServer());
  }

  async function registerUser(): Promise<{
    cookie: string;
    user: PublicUser;
  }> {
    emailCounter += 1;
    const response = await server()
      .post(`${API}/auth/register`)
      .send({
        email: `drawing-${emailCounter}@example.com`,
        password: PASSWORD,
        name: `Drawing User ${emailCounter}`,
      })
      .expect(201);

    return {
      cookie: cookiePair(response),
      user: response.body as PublicUser,
    };
  }

  async function createProject(cookie: string): Promise<PublicProject> {
    const response = await server()
      .post(`${API}/projects`)
      .set('Cookie', cookie)
      .send({ name: `Drawing project ${emailCounter}` })
      .expect(201);

    return response.body as PublicProject;
  }

  async function createFloor(
    cookie: string,
    projectId: string,
    name = 'Floor 1',
  ): Promise<PublicFloor> {
    const response = await server()
      .post(`${API}/projects/${projectId}/floors`)
      .set('Cookie', cookie)
      .send({ name })
      .expect(201);

    return response.body as PublicFloor;
  }

  async function createBlankPlan(
    cookie: string,
    floorId: string,
  ): Promise<PublicPlan> {
    const response = await server()
      .post(`${API}/floors/${floorId}/plans`)
      .set('Cookie', cookie)
      .expect(201);

    return response.body as PublicPlan;
  }

  interface Fixture {
    cookie: string;
    plan: PublicPlan;
  }

  async function createFixture(): Promise<Fixture> {
    const { cookie } = await registerUser();
    const project = await createProject(cookie);
    const floor = await createFloor(cookie, project.id);
    const plan = await createBlankPlan(cookie, floor.id);

    return { cookie, plan };
  }

  async function addPoint(
    { cookie, plan }: Fixture,
    body: Record<string, unknown>,
  ): Promise<PublicPoint> {
    const response = await server()
      .post(`${API}/plans/${plan.id}/points`)
      .set('Cookie', cookie)
      .send(body)
      .expect(201);

    return response.body as PublicPoint;
  }

  async function addRoute(
    { cookie, plan }: Fixture,
    body: Record<string, unknown>,
  ): Promise<PublicRoute> {
    const response = await server()
      .post(`${API}/plans/${plan.id}/routes`)
      .set('Cookie', cookie)
      .send(body)
      .expect(201);

    return response.body as PublicRoute;
  }

  function calibrate(fixture: Fixture): request.Test {
    return server()
      .put(`${API}/plans/${fixture.plan.id}/calibration`)
      .set('Cookie', fixture.cookie)
      .send({
        pointA: { x: 0, y: 0 },
        pointB: { x: 100, y: 0 },
        realDistance: 1,
        unit: 'm',
      });
  }

  it('requires authentication on every drawing endpoint', async () => {
    await server().get(`${API}/plans/${MISSING}/drawing`).expect(401);
    await server().get(`${API}/plans/${MISSING}/calculation`).expect(401);
    await server().put(`${API}/plans/${MISSING}/calibration`).send({}).expect(401);
    await server().delete(`${API}/plans/${MISSING}/calibration`).expect(401);
    await server().post(`${API}/plans/${MISSING}/points`).send({}).expect(401);
    await server().patch(`${API}/points/${MISSING}`).send({}).expect(401);
    await server().delete(`${API}/points/${MISSING}`).expect(401);
    await server().post(`${API}/plans/${MISSING}/routes`).send({}).expect(401);
    await server().patch(`${API}/routes/${MISSING}`).send({}).expect(401);
    await server().delete(`${API}/routes/${MISSING}`).expect(401);
  });

  it('returns an empty drawing for a new plan', async () => {
    const fixture = await createFixture();
    const response = await server()
      .get(`${API}/plans/${fixture.plan.id}/drawing`)
      .set('Cookie', fixture.cookie)
      .expect(200);

    expect(response.body).toEqual({
      planId: fixture.plan.id,
      calibration: null,
      points: [],
      routes: [],
    });
  });

  it('saves, replaces and removes the scale calibration', async () => {
    const fixture = await createFixture();

    const first = (await calibrate(fixture).expect(200)).body as PublicCalibration;
    expect(first.metersPerUnit).toBeCloseTo(0.01, 12);

    const second = await server()
      .put(`${API}/plans/${fixture.plan.id}/calibration`)
      .set('Cookie', fixture.cookie)
      .send({ pointA: { x: 0, y: 0 }, pointB: { x: 300, y: 400 }, realDistance: 250, unit: 'cm' })
      .expect(200);
    expect((second.body as PublicCalibration).metersPerUnit).toBeCloseTo(0.005, 12);

    const drawing = await server()
      .get(`${API}/plans/${fixture.plan.id}/drawing`)
      .set('Cookie', fixture.cookie)
      .expect(200);
    expect((drawing.body as PlanDrawing).calibration?.unit).toBe('cm');

    await server()
      .delete(`${API}/plans/${fixture.plan.id}/calibration`)
      .set('Cookie', fixture.cookie)
      .expect(204);
    const after = await server()
      .get(`${API}/plans/${fixture.plan.id}/drawing`)
      .set('Cookie', fixture.cookie)
      .expect(200);
    expect((after.body as PlanDrawing).calibration).toBeNull();
  });

  it('rejects invalid calibration input', async () => {
    const fixture = await createFixture();
    const put = (body: unknown) =>
      server()
        .put(`${API}/plans/${fixture.plan.id}/calibration`)
        .set('Cookie', fixture.cookie)
        .send(body as object);

    await put({ pointA: { x: 0, y: 0 }, pointB: { x: 0, y: 0 }, realDistance: 1 }).expect(400);
    await put({ pointA: { x: 0, y: 0 }, pointB: { x: 5, y: 0 }, realDistance: 0 }).expect(400);
    await put({ pointA: { x: 0, y: 0 }, pointB: { x: 5, y: 0 }, realDistance: -2 }).expect(400);
    await put({ pointA: { x: 0, y: 0 }, pointB: { x: 5, y: 0 }, realDistance: 1, unit: 'ft' }).expect(400);
    await put({}).expect(400);
  });

  it('creates, updates and deletes electrical points', async () => {
    const fixture = await createFixture();
    const point = await addPoint(fixture, { type: 'socket', x: 10, y: 20, label: 'S1' });

    expect(point).toMatchObject({ type: 'socket', x: 10, y: 20, rotation: 0, label: 'S1' });

    const updated = await server()
      .patch(`${API}/points/${point.id}`)
      .set('Cookie', fixture.cookie)
      .send({ x: 30, rotation: 90, properties: { verticalDropMeters: 2 } })
      .expect(200);
    expect(updated.body).toMatchObject({
      x: 30,
      y: 20,
      rotation: 90,
      properties: { verticalDropMeters: 2 },
    });

    await server()
      .patch(`${API}/points/${point.id}`)
      .set('Cookie', fixture.cookie)
      .send({})
      .expect(400);
    await server()
      .post(`${API}/plans/${fixture.plan.id}/points`)
      .set('Cookie', fixture.cookie)
      .send({ type: 'toaster', x: 0, y: 0 })
      .expect(400);

    await server().delete(`${API}/points/${point.id}`).set('Cookie', fixture.cookie).expect(204);
    await server().delete(`${API}/points/${point.id}`).set('Cookie', fixture.cookie).expect(404);
  });

  it('creates, updates and deletes cable routes', async () => {
    const fixture = await createFixture();
    const route = await addRoute(fixture, {
      geometry: [{ x: 0, y: 0 }, { x: 100, y: 0 }],
      circuitId: 'L1',
    });
    expect(route.settings).toEqual({});

    const updated = await server()
      .patch(`${API}/routes/${route.id}`)
      .set('Cookie', fixture.cookie)
      .send({
        geometry: [{ x: 0, y: 0 }, { x: 100, y: 0 }, { x: 100, y: 50 }],
        settings: { wastePercent: 15 },
      })
      .expect(200);
    expect((updated.body as PublicRoute).geometry).toHaveLength(3);
    expect((updated.body as PublicRoute).settings.wastePercent).toBe(15);

    await server()
      .post(`${API}/plans/${fixture.plan.id}/routes`)
      .set('Cookie', fixture.cookie)
      .send({ geometry: [{ x: 0, y: 0 }] })
      .expect(400);
    await server()
      .post(`${API}/plans/${fixture.plan.id}/routes`)
      .set('Cookie', fixture.cookie)
      .send({ geometry: [{ x: 0, y: 0 }, { x: 1, y: 1 }], settings: { wastePercent: 500 } })
      .expect(400);

    await server().delete(`${API}/routes/${route.id}`).set('Cookie', fixture.cookie).expect(204);
    const drawing = await server()
      .get(`${API}/plans/${fixture.plan.id}/drawing`)
      .set('Cookie', fixture.cookie)
      .expect(200);
    expect((drawing.body as PlanDrawing).routes).toEqual([]);
  });

  it('calculates 24 m + drops + 10% waste = 33 m on the server', async () => {
    const fixture = await createFixture();
    await calibrate(fixture).expect(200); // 0.01 m per drawing unit

    const panel = await addPoint(fixture, { type: 'panel', x: 0, y: 0, label: 'Panel' });
    // Lies on the route but is not an end, so it must add no drop.
    await addPoint(fixture, { type: 'socket', x: 1200, y: 0, label: 'S1' });
    const light = await addPoint(fixture, {
      type: 'light',
      x: 2400,
      y: 0,
      properties: { verticalDropMeters: 4.5 }, // override: 4.5 m
    });
    await addRoute(fixture, {
      geometry: [{ x: 0, y: 0 }, { x: 2400, y: 0 }],
      circuitId: 'L1',
    });

    const response = await server()
      .get(`${API}/plans/${fixture.plan.id}/calculation`)
      .set('Cookie', fixture.cookie)
      .expect(200);
    const result = response.body as PlanCalculation;

    // Ends: panel at x=0 (0 m) and light at x=2400 (4.5 m override).
    expect(result.metersPerUnit).toBeCloseTo(0.01, 12);
    expect(result.routes).toHaveLength(1);
    expect(result.routes[0]).toMatchObject({
      status: 'ok',
      circuitId: 'L1',
      planLength: 24,
      verticalLength: 4.5,
      wastePercent: 10,
    });
    expect(result.routes[0]?.drops.map((d) => d.pointId).sort()).toEqual([panel.id, light.id].sort());
    expect(result.routes[0]?.requiredLength).toBeCloseTo((24 + 4.5) * 1.1, 6);
    expect(result.totalRequiredLength).toBeCloseTo(31.35, 6);
    expect(result.warnings).toEqual([]);
  });

  it('matches the specification example of exactly 33 m', async () => {
    const fixture = await createFixture();
    await calibrate(fixture).expect(200);
    await addPoint(fixture, { type: 'socket', x: 0, y: 0 }); // 1.5 m
    await addPoint(fixture, { type: 'light', x: 2400, y: 0, properties: { verticalDropMeters: 4.5 } });
    await addRoute(fixture, { geometry: [{ x: 0, y: 0 }, { x: 2400, y: 0 }] });

    const result = (
      await server()
        .get(`${API}/plans/${fixture.plan.id}/calculation`)
        .set('Cookie', fixture.cookie)
        .expect(200)
    ).body as PlanCalculation;

    expect(result.routes[0]).toMatchObject({
      planLength: 24,
      verticalLength: 6,
      wasteLength: 3,
      requiredLength: 33,
    });
    expect(result.totalRequiredLength).toBe(33);
  });

  it('honours a per-route waste percentage and re-scales after recalibration', async () => {
    const fixture = await createFixture();
    await calibrate(fixture).expect(200);
    await addRoute(fixture, {
      geometry: [{ x: 0, y: 0 }, { x: 1000, y: 0 }],
      settings: { wastePercent: 0 },
    });

    const read = async () =>
      (
        await server()
          .get(`${API}/plans/${fixture.plan.id}/calculation`)
          .set('Cookie', fixture.cookie)
          .expect(200)
      ).body as PlanCalculation;

    expect((await read()).routes[0]?.requiredLength).toBe(10);

    await server()
      .put(`${API}/plans/${fixture.plan.id}/calibration`)
      .set('Cookie', fixture.cookie)
      .send({ pointA: { x: 0, y: 0 }, pointB: { x: 100, y: 0 }, realDistance: 2 })
      .expect(200);
    expect((await read()).routes[0]?.requiredLength).toBe(20);
  });

  it('does not invent lengths for an uncalibrated plan and warns about open route ends', async () => {
    const fixture = await createFixture();
    await addRoute(fixture, {
      geometry: [{ x: 0, y: 0 }, { x: 50, y: 0 }],
      circuitId: 'L2',
    });

    const result = (
      await server()
        .get(`${API}/plans/${fixture.plan.id}/calculation`)
        .set('Cookie', fixture.cookie)
        .expect(200)
    ).body as PlanCalculation;

    expect(result.metersPerUnit).toBeNull();
    expect(result.totalRequiredLength).toBeNull();
    expect(result.routes[0]).toMatchObject({ status: 'uncalibrated', requiredLength: null });
    expect(result.warnings.some((w) => w.includes('not calibrated'))).toBe(true);
    expect(result.warnings.some((w) => w.includes('L2'))).toBe(true);
  });

  it('isolates drawings between users (IDOR)', async () => {
    const owner = await createFixture();
    const intruder = await registerUser();
    const point = await addPoint(owner, { type: 'socket', x: 1, y: 1 });
    const route = await addRoute(owner, { geometry: [{ x: 0, y: 0 }, { x: 1, y: 1 }] });
    const as = (r: request.Test) => r.set('Cookie', intruder.cookie);

    await as(server().get(`${API}/plans/${owner.plan.id}/drawing`)).expect(404);
    await as(server().get(`${API}/plans/${owner.plan.id}/calculation`)).expect(404);
    await as(server().put(`${API}/plans/${owner.plan.id}/calibration`))
      .send({ pointA: { x: 0, y: 0 }, pointB: { x: 1, y: 0 }, realDistance: 1 })
      .expect(404);
    await as(server().delete(`${API}/plans/${owner.plan.id}/calibration`)).expect(404);
    await as(server().post(`${API}/plans/${owner.plan.id}/points`))
      .send({ type: 'socket', x: 0, y: 0 })
      .expect(404);
    await as(server().patch(`${API}/points/${point.id}`)).send({ x: 99 }).expect(404);
    await as(server().delete(`${API}/points/${point.id}`)).expect(404);
    await as(server().post(`${API}/plans/${owner.plan.id}/routes`))
      .send({ geometry: [{ x: 0, y: 0 }, { x: 1, y: 1 }] })
      .expect(404);
    await as(server().patch(`${API}/routes/${route.id}`)).send({ circuitId: 'X' }).expect(404);
    await as(server().delete(`${API}/routes/${route.id}`)).expect(404);

    // The owner's data is untouched.
    const drawing = (
      await server()
        .get(`${API}/plans/${owner.plan.id}/drawing`)
        .set('Cookie', owner.cookie)
        .expect(200)
    ).body as PlanDrawing;
    expect(drawing.points[0]).toMatchObject({ id: point.id, x: 1 });
    expect(drawing.routes).toHaveLength(1);
  });
});
