import type {
  PlanCalculation,
  PlanDrawing,
  PublicCalibration,
  SetCalibrationInput,
} from '@drawmyplace/contracts';
import { apiRequest } from '@/lib/api';

export function getPlanDrawing(
  planId: string,
  signal?: AbortSignal,
): Promise<PlanDrawing> {
  return apiRequest<PlanDrawing>(`/plans/${planId}/drawing`, { signal });
}

export function getPlanCalculation(
  planId: string,
  signal?: AbortSignal,
): Promise<PlanCalculation> {
  return apiRequest<PlanCalculation>(`/plans/${planId}/calculation`, {
    signal,
  });
}

export function saveCalibration(
  planId: string,
  input: SetCalibrationInput,
): Promise<PublicCalibration> {
  return apiRequest<PublicCalibration>(`/plans/${planId}/calibration`, {
    method: 'PUT',
    body: JSON.stringify(input),
  });
}

export async function removeCalibration(planId: string): Promise<void> {
  await apiRequest<void>(`/plans/${planId}/calibration`, {
    method: 'DELETE',
  });
}
